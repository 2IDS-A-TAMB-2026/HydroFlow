<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors", 1);

$arquivo = __DIR__ . "/admin.json"; // arquivo que vai guardar os dados
$erro = "";
$sucesso = "";

// Verifica se já existe um admin cadastrado
$adminExistente = file_exists($arquivo) && filesize($arquivo) > 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = trim($_POST["usuario"]);
    $senha = trim($_POST["senha"]);

    if (empty($usuario) || empty($senha)) {
        $erro = "Preencha todos os campos!";
    } else {
        // salva os dados no JSON
        $dados_admin = [
            "usuario" => $usuario,
            "senha" => password_hash($senha, PASSWORD_DEFAULT)
        ];

        file_put_contents($arquivo, json_encode($dados_admin, JSON_PRETTY_PRINT));

        $sucesso = "Cadastro realizado com sucesso!";
        header("Refresh:2; url=login_adm.php");
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro Admin</title>
</head>
<body>

<h2>Cadastro Admin</h2>

<?php
// 🔹 Mensagens de erro ou sucesso
if (!empty($erro)) {
    echo "<p style='color:red;'>$erro</p>";
}

if (!empty($sucesso)) {
    echo "<p style='color:green;'>$sucesso</p>";
    echo "<p>Redirecionando para o login...</p>";
}

// 🔹 Mostra link para login apenas se já existir admin cadastrado
if (!$sucesso && $adminExistente) {
    echo '<p>Já tem cadastro? <a href="login_adm.php">Clique aqui para fazer login</a></p>';
}
?>

<?php if (empty($sucesso)): ?>
<form method="POST">
    <label>Email:</label><br>
    <input type="email" name="usuario" required><br><br>

    <label>Senha:</label><br>
    <input type="password" name="senha" required><br><br>

    <button type="submit">Cadastrar</button>
</form>
<?php endif; ?>

</body>
</html>