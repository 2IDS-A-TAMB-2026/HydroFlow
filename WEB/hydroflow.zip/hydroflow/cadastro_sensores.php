<?php
session_start();

// 🔒 PROTEÇÃO: só admin entra
if (!isset($_SESSION["usuario"]) || $_SESSION["tipo"] != "admin") {
    header("Location: login_admin.php");
    exit;
}

$erro = "";
$sucesso = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nomeSensor = $_POST["nomeSensor"] ?? "";
    $tipoSensor = $_POST["tipoSensor"] ?? "";

    if (empty($nomeSensor) || empty($tipoSensor)) {
        $erro = "Preencha todos os campos!";
    } else {

        // 🔥 SALVA O SENSOR
        $_SESSION["sensores"][] = [
            "nome" => $nomeSensor,
            "tipo" => $tipoSensor
        ];

        $sucesso = "Sensor cadastrado com sucesso!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Cadastro de sensores</title>
    <meta charset="UTF-8">

<?php if (!empty($sucesso)) { ?>
    <!-- 🔥 Corrigido: manda pro painel ADMIN -->
    <meta http-equiv="refresh" content="2;url=painel_admin.php">
<?php } ?>

</head>
<body>    
    <h2>Cadastro de Sensores</h2>

<?php
if (!empty($erro)) {
    echo "<p style='color:red;'>$erro</p>";
}

if (!empty($sucesso)) {
    echo "<p style='color:green;'>$sucesso</p>";
    echo "<p>Redirecionando...</p>";
}
?>

<form method="POST">

    <label>Nome do sensor:</label><br>
    <input type="text" name="nomeSensor"><br><br>

    <label>Tipo do sensor:</label><br>
    <input type="text" name="tipoSensor"><br><br>

    <button type="submit">Cadastrar</button>
    
</form>

<br>
<a href="painel_admin.php">⬅ Voltar</a>

</body>
</html>