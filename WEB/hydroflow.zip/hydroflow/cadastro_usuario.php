<?php
session_start();

if (isset($_POST["usuario"]) && isset($_POST["senha"])) {

    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];

    // SALVANDO EM SESSÃO (simples, sem banco)
    $_SESSION["novo_usuario"] = $usuario;
    $_SESSION["nova_senha"] = $senha;

    $sucesso = "Usuário cadastrado com sucesso!";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - Hydroflow</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <style>
        :root {
            --azul-primario: #002855;
            --azul-royal: #0056B3;
            --azul-cyan: #4DD0E1;
            --azul-claro: #F0FFFF;
        }

        body {
            background-color: var(--azul-claro);
            font-family: Arial, sans-serif;
        }

        .box {
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
        }

        .btn {
            background-color: var(--azul-primario);
            color: white;
            width: 100%;
            margin-top: 15px;
        }

        .msg {
            text-align: center;
            color: green;
        }
    </style>
</head>

<body>

<div class="box w3-card">

    <h2 style="text-align:center;">Cadastro de Usuário</h2>

    <?php if (isset($sucesso)) echo "<p class='msg'>$sucesso</p>"; ?>

    <form method="POST">

        <label>CPF</label>
        <input class="w3-input w3-section" type="text" name="usuario" required>

        <label>Senha</label>
        <input class="w3-input w3-section" type="password" name="senha" required>

        <button class="w3-button btn" type="submit">Cadastrar</button>

    </form>

    <a href="login.php" style="display:block;text-align:center;margin-top:15px;">
        Já tem conta? Fazer login
    </a>

</div>

</body>
</html>