<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

session_start();

echo "FUNCIONANDO";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Hydroflow - Irrigação Automática</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        :root {
            --azul-primario: #002855;   
            --azul-royal: #0056B3;     
            --azul-cyan: #4DD0E1;      
            --azul-borda: #B2EBF2;     
            --azul-claro: #F0FFFF;     
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--azul-claro);
        }

        .w3-top .w3-bar {
            background-color: white !important;
            border-bottom: 3px solid var(--azul-cyan);
        }

        .w3-button.w3-black {
            background-color: var(--azul-primario) !important;
        }

        .img-redonda {
            width: 200px;
            height: 200px;
            object-fit: cover;
            border-radius: 50%;
        }

        .img-equipe {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<div class="w3-right">

<?php if (!empty($_SESSION["usuario"])): ?>

    <span class="w3-bar-item">
        Olá, <?php echo $_SESSION["usuario"]; ?>
    </span>

    <?php if (!empty($_SESSION["tipo"]) && $_SESSION["tipo"] == "admin"): ?>
        <a href="painel_admin.php" class="w3-bar-item w3-button">Painel Admin</a>
    <?php else: ?>
        <a href="painel_usuario.php" class="w3-bar-item w3-button">Painel</a>
    <?php endif; ?>

    <a href="logout.php" class="w3-bar-item w3-button">Sair</a>

<?php else: ?>

    <a href="login.php" class="w3-bar-item w3-button">Login</a>
    <a href="cadastro_usuario.php" class="w3-bar-item w3-button">Cadastrar</a>

<?php endif; ?>

<a href="cadastro_adm.php" class="w3-bar-item w3-button">Admin</a>

</div>

<!-- HEADER -->
<header class="w3-container w3-center" id="home" style="margin-top:80px;">
    <h1>Hydroflow</h1>
    <p>Irrigação inteligente</p>
</header>

<!-- CONTEÚDO -->
<div class="w3-container w3-padding">

    <h2>Bem-vindo ao sistema</h2>
    <p>Gerencie sua irrigação de forma inteligente.</p>

</div>

<footer class="w3-center w3-black w3-padding-16">
  <p>© Hydroflow 2026</p>
</footer>

</body>
</html>