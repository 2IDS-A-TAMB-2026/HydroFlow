<?php
session_start();

if (!isset($_SESSION["usuario"]) || $_SESSION["tipo"] != "admin") {
    header("Location: login_admin.php");
    exit;
}
?>

<h2>Sensores cadastrados</h2>

<?php
if (!empty($_SESSION["sensores"])) {
    foreach ($_SESSION["sensores"] as $sensor) {
        echo "<p>Nome: {$sensor["nome"]} | Tipo: {$sensor["tipo"]}</p>";
    }
} else {
    echo "Nenhum sensor cadastrado.";
}
?>

<a href="painel_admin.php">Voltar</a>