<?php

session_start();

if (isset($_POST["usuario"]) && isset($_POST["senha"])) {

    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];

    if ($usuario === "000.000.000-00" && $senha === "123") {

        $_SESSION["usuario"] = $usuario;
        $_SESSION["tipo"] = "usuario";

        header("Location: painel_usuario.php");
        exit;

    } else {
        $erro = "Usuário ou senha inválidos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - Hydroflow</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- W3CSS -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <style>
        :root {
            --azul-primario: #002855;
            --azul-royal: #0056B3;
            --azul-cyan: #4DD0E1;
            --azul-claro: #F0FFFF;
        }

        body {
            background-color: var(--azul-claro);
            font-family: Arial, sans-serif;
        }

        .login-box {
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: var(--azul-primario);
        }

        .w3-input {
            border-bottom: 1px solid var(--azul-cyan) !important;
        }

        .w3-input:focus {
            border-bottom: 2px solid var(--azul-royal) !important;
            outline: none;
        }

        .btn {
            background-color: var(--azul-primario);
            color: white;
            width: 100%;
            margin-top: 15px;
        }

        .btn:hover {
            background-color: var(--azul-royal);
        }

        .erro {
            color: red;
            text-align: center;
        }

        .voltar {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: var(--azul-primario);
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="login-box w3-card">

    <h2>Login Hydroflow</h2>

    <?php if (isset($erro)) echo "<p class='erro'>$erro</p>"; ?>

    <form method="POST">

        <label>CPF</label>
        <input class="w3-input w3-section" type="text" name="usuario" required>

        <label>Senha</label>
        <input class="w3-input w3-section" type="password" name="senha" required>

        <button class="w3-button btn" type="submit">Entrar</button>

    </form>

    <a href="index.php" class="voltar">⬅ Voltar ao site</a>

</div>

</body>
</html>