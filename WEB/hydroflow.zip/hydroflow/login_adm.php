<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors", 1);

$arquivo = __DIR__ . "/admin.json"; // JSON com admin
$erro = "";

// Se não existir admin, bloqueia login
if (!file_exists($arquivo) || filesize($arquivo) == 0) {
    die("Nenhum admin cadastrado. Cadastre um admin primeiro.");
}

$dados_admin = json_decode(file_get_contents($arquivo), true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST["usuario"]);
    $senha = trim($_POST["senha"]);

    if (empty($usuario) || empty($senha)) {
        $erro = "Preencha todos os campos!";
    } else {
        // verifica usuário e senha
        if ($usuario === $dados_admin["usuario"] && password_verify($senha, $dados_admin["senha"])) {
            $_SESSION["tipo"] = "admin"; // marca como logado
            header("Location: painel_adm.php"); // redireciona para o painel
            exit;
        } else {
            $erro = "Usuário ou senha incorretos!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login Admin</title>
</head>
<body>

<h2>Login Admin</h2>

<?php if(!empty($erro)) echo "<p style='color:red;'>$erro</p>"; ?>

<form method="POST">
    <label>Email:</label><br>
    <input type="email" name="usuario" required><br><br>

    <label>Senha:</label><br>
    <input type="password" name="senha" required><br><br>

    <button type="submit">Entrar</button>
</form>

<p><a href="cadastro_adm.php">Voltar para Cadastro</a></p>

</body>
</html>