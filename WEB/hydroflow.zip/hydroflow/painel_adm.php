<?php
session_start();
error_reporting(E_ALL);
ini_set("display_errors", 1);

// 🔹 Proteção de login
if (!isset($_SESSION["tipo"]) || $_SESSION["tipo"] !== "admin") {
    header("Location: login_adm.php");
    exit;
}

$arquivo = __DIR__ . "/sensores.json";
$erro = "";
$sucesso = "";

// 🔹 Cadastro de sensor
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST["nome"]);
    $tipo = trim($_POST["tipo"]);
    $status = trim($_POST["status"]);

    if (empty($nome) || empty($tipo) || empty($status)) {
        $erro = "Preencha todos os campos!";
    } else {
        $sensores = [];

        if (file_exists($arquivo)) {
            $sensores = json_decode(file_get_contents($arquivo), true);
        }

        $sensores[] = [
            "nome" => $nome,
            "tipo" => $tipo,
            "status" => $status
        ];

        file_put_contents($arquivo, json_encode($sensores, JSON_PRETTY_PRINT));

        $sucesso = "Sensor cadastrado com sucesso!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Painel Admin</title>
<style>
    body { font-family: Arial; margin: 20px; }
    table { border-collapse: collapse; width: 400px; }
    th, td { border: 1px solid #000; padding: 8px; }
</style>
</head>
<body>

<h2>Painel Admin - Sensores</h2>

<p><a href="logout_adm.php">Sair</a></p>

<?php
if ($erro) echo "<p style='color:red;'>$erro</p>";
if ($sucesso) echo "<p style='color:green;'>$sucesso</p>";
?>

<form method="POST">
    <label>Nome:</label><br>
    <input type="text" name="nome"><br><br>

    <label>Tipo:</label><br>
    <input type="text" name="tipo"><br><br>

    <label>Status:</label><br>
    <select name="status">
        <option value="">Selecione</option>
        <option value="ativo">Ativo</option>
        <option value="inativo">Inativo</option>
    </select><br><br>

    <button type="submit">Cadastrar Sensor</button>
</form>

<hr>

<h3>Sensores cadastrados:</h3>

<?php
if (file_exists($arquivo)) {
    $sensores = json_decode(file_get_contents($arquivo), true);

    if (!empty($sensores)) {
        echo "<table>";
        echo "<tr><th>Nome</th><th>Tipo</th><th>Status</th></tr>";

        foreach ($sensores as $s) {
            echo "<tr>
                    <td>{$s['nome']}</td>
                    <td>{$s['tipo']}</td>
                    <td>{$s['status']}</td>
                  </tr>";
        }

        echo "</table>";
    } else {
        echo "<p>Nenhum sensor cadastrado ainda.</p>";
    }
} else {
    echo "<p>Nenhum sensor cadastrado ainda.</p>";
}
?>

</body>
</html>