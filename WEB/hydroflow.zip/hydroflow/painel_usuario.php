<?php
session_start();

// PROTEÇÃO
if (!isset($_SESSION["usuario"]) || $_SESSION["tipo"] != "usuario") {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel do Usuário</title>
</head>
<body>

<h1>Bem-vindo ao sistema Hydroflow 👨‍🌾</h1>

<p>Usuário: <?php echo $_SESSION["usuario"]; ?></p>

<a href="logout.php">Sair</a>

</body>
</html>